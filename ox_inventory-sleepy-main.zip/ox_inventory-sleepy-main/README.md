
# Notes if you want to replace the build!!!

Add This to fxmanifest.lua inside files

```lua
    'web/build/assets/*.png',
```
### Replace on client.lua

from
```lua
for i = 1, 5 do
```
to
```lua
for i = 1, 6 do
```

![Inventory](https://cdn.discordapp.com/attachments/1015237128445243433/1155611518939963553/image.png)


# Preview

![Inventory](https://cdn.discordapp.com/attachments/1015237128445243433/1155604356197007410/image.png)

![Half](https://cdn.discordapp.com/attachments/1015237128445243433/1155607930129887262/image.png)

![Full](https://cdn.discordapp.com/attachments/1015237128445243433/1155607993698758696/image.png)

![Glovebox](https://cdn.discordapp.com/attachments/1015237128445243433/1155604397825470576/image.png)

![Hotbar](https://cdn.discordapp.com/attachments/1015237128445243433/1155604438967394406/image.png)

![Crafting](https://cdn.discordapp.com/attachments/1015237128445243433/1155606418741801040/image.png)

![Stash](https://cdn.discordapp.com/attachments/1015237128445243433/1155607742116016238/image.png)
