# circle-speedo
circle speedo

plugin free.
depends only on standart includes + cprogress.inc for circle progress ofc
