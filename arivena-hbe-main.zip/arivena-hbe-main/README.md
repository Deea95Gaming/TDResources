preview ntd
![Screenshot](https://github.com/Aufaruq/arivena-hbe/blob/main/Screenshot_5593.png)

preview ingame
![Screenshot](https://github.com/Aufaruq/arivena-hbe/blob/main/Screenshot_5594.png)

credit : arivena
create td : Aufa
create scrip : Aufa
