# Nopixel-4.0-inventory
nopixel 4.0 inventory customize 
![image](https://github.com/pooyahpx/Nopixel-4.0-inventory/assets/73234330/528f907f-377b-4b85-ae27-f4503223a563)

help for installation:

1. download resource
2. drag and drop in your server source
3. rename it to qb-inventory
4. if you use other inventory change all to qb-inventory ( like ps-inventory to qb-inventory )
